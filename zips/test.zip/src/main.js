(function() {
    console.log('hello')
    
    
    console.log('Yo mel')
})()